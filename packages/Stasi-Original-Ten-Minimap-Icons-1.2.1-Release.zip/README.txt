Stasi Original Ten Minimap Icons 1.2.1

For stock Diddy Kong Racing Recompiled 1.0.15, offline play.
Supported Game Pak revisions: us.v77 and us.v80.

Adds Stasi's supplied minimap portraits for the original ten racers, including
T.T. and Drumstick. Portraits stay upright; the human player's portrait has a
cyan ring. Uses the approved smaller artwork presentation.

INSTALL
1. Extract this ZIP. In DKR-R's Custom Magic Codes, import
   Stasi-Original-Ten-Minimap-Icons-1.2.1.nrm.
2. Select version 1.2.1, approve if prompted, and enable it. Keep session mods
   ON and disable other minimap implementations. Importing alone is not enough.
3. Restart DKR-R and start an offline game. No typed code or modified engine
   is needed. Keep older packages if you want to roll back later.

CUSTOM CHARACTERS
The core does not require custom characters to supply icons. Without an enabled
compatible optional icon, a custom human racer keeps its normal arrow and a
custom CPU keeps its normal dot. Original portraits and native markers can
share one minimap. A custom racer does not inherit its donor's portrait.
Matching optional icon companions are separate and are not included here.
See COMPATIBILITY.txt for their exact limits and the tested scope.

DISABLE OR ROLL BACK
Disable any separately installed dependent icon companions first, then disable
this core and restart. Characters remain usable without these cosmetics.
To return to a retained older core, select that edition and restart with only
one minimap implementation enabled. No save, ROM or game-file edits are needed.

CONTENTS
One .nrm, these instructions, compatibility notes, credits, the SDK license
notice, version provenance and checksums. No engine, DLL, ROM, character model,
profile, save data or optional icon companion is included.
